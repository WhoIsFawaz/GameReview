"use strict";
const FavouritesDB = require('../models/FavouritesDB');
const Favourite = require('../models/Favourite');

var favouritesDB = new FavouritesDB();

function getUserFavourites(request,respond)
{
    var input_username = request.params.username;
    favouritesDB.getUserFavourites(input_username, function(error,result)
    {
        if (error){
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });
}

function addFavourite(request, respond)
{
    var now = new Date();
    var favourite = new Favourite(request.body.favourites_id, request.body.gameid, request.body.username, now.toString());

    favouritesDB.addFavourite(favourite, function(error, result){

        if(error){
            respond.json(error);
        }
        else
        {
            respond.json(result);
        }
    })
}

function deleteFavourite(request, respond)
{
    var favouriteID = request.params.id;
    favouritesDB.deleteFavourite(favouriteID, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}



module.exports = {getUserFavourites, addFavourite, deleteFavourite };