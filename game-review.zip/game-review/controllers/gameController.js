"use strict";

const GamesDB = require('../models/GamesDB');

var gamesDB = new GamesDB();

function getAllGames(request,respond){
    gamesDB.getAllGames(function(error,result)
    {
        if (error){
            respond.json(error);
        } else {
            respond.json(result);
        }
    });
}

function searchGames(request,respond){
    var input_title = request.params.title;
    gamesDB.searchGames(input_title, function(error,result)
    {
        if (error){
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });                                                                         
}

function getPcGames(request, respond){
    gamesDB.getPcGames(function(error,result)
    {
        if (error){
            respond.json(error);
        } else {
            respond.json(result);
        }
    });
}

function getXboxGames(request, respond){
    gamesDB.getXboxGames(function(error,result)
    {
        if (error){
            respond.json(error);
        } else {
            respond.json(result);
        }
    });
}

function getPs4Games(request, respond){
    gamesDB.getPs4Games(function(error,result)
    {
        if (error){
            respond.json(error);
        } else {
            respond.json(result);
        }
    });
}

module.exports = {getAllGames, searchGames, getPcGames, getXboxGames, getPs4Games};