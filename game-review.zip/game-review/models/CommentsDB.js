"use strict"

var db = require('../db-connection')
class CommentsDB{
    getAllComments(callback){
        var sql = "SELECT * from game_database.comments";
        db.query(sql, callback);
    }

    addComment(comment, callback){
        var sql = "INSERT INTO comments (comments_id, gameid, game, username, review, rating, dateposted) VALUES (?,?,?,?,?,?,?)";
        db.query(sql, [comment.getComments_id(), comment.getGameid(), comment.getGame(), comment.getUsername(), comment.getReview(), comment.getRating(), comment.getDateposted()], callback);
    }

    updateComment(comment, callback)
    {
        var sql = "UPDATE comments SET review = ?, rating = ?, dateposted = ? WHERE comments_id = ?";
        return db.query(sql, [ comment.getReview(), comment.getRating(), comment.getDateposted(), comment.getComments_id()], callback);
    }

    deleteComment(commentID, callback){
        var sql = "DELETE from comments WHERE comments_id = ?";
        return db.query(sql, [commentID], callback);
    }
}

module.exports = CommentsDB;