"use strict";
class User{
constructor(yourname, password, email,){
    this.yourname = yourname;
    this.password = password;
    this.email = email;

}

getYourname() {
    return this.yourname
}

getPassword() {
    return this.password
}

getEmail() {
    return this.email
}

setYourname() {
    this.yourname = yourname;
}

setPassword() {
    this.password = password;
}

setEmail() {
    this.email = email;
}

}

module.exports = User;