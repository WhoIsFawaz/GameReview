"use strict"

var db = require('../db-connection'); //reference of DB connection.js

class UserDB{

    getAllUsers(callback){
        var sql = "SELECT * from game_database.user";
        db.query(sql, callback);
    }

    addUser(user, callback){
        var sql = "INSERT INTO user(yourname, password, email) VALUES (?,?,?)";
        db.query(sql, [user.getYourname(), user.getPassword(), user.getEmail()], callback);

    }

    updateUserParticulars(user, callback)
    {
        var sql = "UPDATE user SET password = ?, email = ? WHERE yourname = ?";
        return db.query(sql, [ user.getPassword(), user.getEmail(), user.getYourname()], callback);
    }
    
    authenticateByDB(yourname, password, callback) {
        var sql = "SELECT yourname FROM user WHERE yourname = ? AND password = ?";
        db.query(sql, [yourname, password], callback);
    }

    searchUser(yourname, callback){
        var sql = "SELECT * FROM game_database.user WHERE yourname = ?";
        db.query(sql, [yourname], callback);
    }

    deleteUser(yourname, callback){
        var sql = "DELETE from user WHERE yourname = ?";
        return db.query(sql, [yourname], callback);
    }

}

module.exports = UserDB;