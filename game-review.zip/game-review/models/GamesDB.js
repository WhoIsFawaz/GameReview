"use strict";

var db =  require('../db-connection');

class GamesDB
{
    getAllGames(callback){
        var sql = "SELECT * FROM game_database.game";
        db.query(sql, callback);
    }

    searchGames(title, callback){
        var sql = "SELECT * FROM game_database.game WHERE title LIKE ?";
        db.query(sql, [title + "%"], callback);
    }

    getPcGames(callback){
        var sql = "SELECT * FROM game_database.game WHERE platform = 'PC' ";
        db.query(sql, callback);
    }

    getXboxGames(callback){
        var sql = "SELECT * FROM game_database.game WHERE platform = 'XBOX' ";
        db.query(sql, callback);
    }

    getPs4Games(callback){
        var sql = "SELECT * FROM game_database.game WHERE platform = 'PS4' ";
        db.query(sql, callback);
    }
    
}

module.exports = GamesDB;