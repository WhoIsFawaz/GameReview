"use strict";
class Game {
constructor(game_id, title, description, platform, rating, genre, thumbnail, trailer, download) {
	this.game_id = game_id;
	this.title = title;
	this.description = description;
	this.platform = platform;
	this.rating = rating;
	this.genre = genre;
	this.thumbnail = thumbnail;
    this.trailer = trailer;
    this.download = download;
}
//add the get methods here

getGame_id() {
    return this.game_id;
}

getTitle() {
    return this.title;
}

getDescription() {
    return this.description;
}

getPlatform() {
    return this.platform;
}

getRating() {
    return this.rating;
}

getGenre() {
    return this.genre;
}

getThumbnail() {
    return this.thumbnail;
}

getTrailer() {
    return this.trailer;
}

getDownload() {
    return this.download;
}

}

module.exports = Game;
