"use strict";
class Favourite{
constructor(favourites_id, gameid, username) {
    this.favourites_id = favourites_id;
    this.gameid = gameid;
    this.username = username;
}

getFavourites_id() {
    return this.favourites_id;
}

getGameid() {
    return this.gameid;
}

getUsername() {
    return this.username;
}

setFavourites_id() {
    this.favourites_id = favourites_id;
}

setGameid() {
    this.gameid = gameid;
}

setUsername() {
    this.username = username;
}

}

module.exports = Favourite;