"use strict";
class Comment {
constructor(comments_id, gameid, game, username, review, rating, dateposted) {
this.comments_id = comments_id;
this.gameid = gameid;
this.game = game;
this.username = username;
this.review = review;
this.rating = rating;
this.dateposted = dateposted;
}
//add the set and get methods here}

getComments_id() {
    return this.comments_id;
}

getGameid() {
    return this.gameid;
}

getGame() {
    return this.game;
}

getUsername() {
    return this.username;
}

getReview() {
    return this.review;
}

getRating() {
    return this.rating;
}

getDateposted() {
    return this.dateposted;
}

setGameid(gameid) {
    this.gameid = gameid;
}

setGame(game) {
    this.movie = game;
}

setUsername(username) {
    this.username = username;
}

setReview(review) {
    this.review = review;
}

setRating(rating) {
    this.rating = rating;
}

setDateposted(dateposted) {
    this.dateposted = dateposted;
}

}
module.exports = Comment;
