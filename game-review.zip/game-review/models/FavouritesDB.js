"use strict"

var db = require('../db-connection')
class FavouritesDB{

     getUserFavourites(username, callback){
        var sql = "SELECT favourites_id, gameid, title, username FROM game_database.favourites JOIN game_database.game ON favourites.gameid = game.game_id WHERE username= ?";
        db.query(sql, [username], callback);
    }

    addFavourite(favourites, callback){
        var sql = "INSERT INTO favourites (favourites_id, gameid, username) VALUES (?,?,?)";
        db.query(sql, [favourites.getFavourites_id(), favourites.getGameid(), favourites.getUsername()], callback);
    }

    deleteFavourite(commentID, callback){
        var sql = "DELETE from favourites WHERE favourites_id = ?";
        return db.query(sql, [commentID], callback);
    }

}

module.exports = FavouritesDB;