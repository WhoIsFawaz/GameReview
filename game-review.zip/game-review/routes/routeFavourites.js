"use strict";

const favouriteController = require('../controllers/favouriteController');

function routeFavourites(app)
{
    app.route('/favourites')
        .post(favouriteController.addFavourite);

    app.route('/favourites/:id')
        .delete(favouriteController.deleteFavourite);

    app.route('/favourites/:username')
        .get(favouriteController.getUserFavourites)
}
module.exports = {routeFavourites};