"use strict"

const userController = require('../controllers/userController');

function routeUsers(app) 
{
    app.route('/loginByDB')
        .post(userController.authenticateByDB);

    app.route('/user')
        .post(userController.addUser)
        .get(userController.getAllUsers)
    
    app.route('/user/:yourname')
        .get(userController.searchUser)
        .put(userController.updateUserParticulars)
        .delete(userController.deleteUser);

}

module.exports = { routeUsers };