"use strict"

const gameController = require('../controllers/gameController');

function routeGames(app)
{
    app.route('/games')
        .get(gameController.getAllGames)

    app.route('/getPcGames')
        .get(gameController.getPcGames)

    app.route('/getXboxGames')
        .get(gameController.getXboxGames)
    
    app.route('/getPs4Games')
        .get(gameController.getPs4Games)
    
    app.route('/games/:title')
        .get(gameController.searchGames)
        
}

module.exports = { routeGames };