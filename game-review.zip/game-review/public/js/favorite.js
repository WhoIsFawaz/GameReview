function fetchFavorite() {

    var request = new XMLHttpRequest();

    var urlParams = new URLSearchParams(window.location.search);
            var yourname = urlParams.getAll('yourname');
            var add_Favorite = fav_url+"/"+ yourname;

    request.open('GET', add_Favorite, true);

    //This command starts the calling of the comments api
    request.onload = function () {
        //get all the comments records into our comments array
        fav_array = JSON.parse(request.responseText);
        

    };


    request.send();
}
function showGameFav(element) {

    document.getElementById("emptyComment").innerHTML = "No favorite yet. add one now";

    //var item = element.getAttribute("item");
    //currentIndex = item;
    //console.log("item " + item)

    //document.getElementById("review").textContent = "Review for " + game_array[item].title;
    document.getElementById("fav").textContent = "My favorites";
    document.getElementById("favoriteBody").textContent = "";

    for (var i = 0; i < fav_array.length; i++) {
    
        {
            document.getElementById("emptyComments").innerHTML = "";
            selectedfavId = fav_array[0].favourites_id;

            var html = '<div class="text-center" style="width:100%;">                                                           \
                            <div class="card">                                                                                  \
                                <div class="card-body">                                                                         \
                                    <p class="card-text" id="rating' + i + '">' + fav_array[i].title + "</p>               \
                                    <small>by " + fav_array[i].username  + "</small>   \
                                </div>                                                                                          \
                            </div>                                                                                              \
                        </div>";
                        
            document.getElementById("favoriteBody").insertAdjacentHTML('beforeend', html);
        }
    }
}

