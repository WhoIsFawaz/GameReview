function fetchUser() {
    var request = new XMLHttpRequest();
    request.open('GET', user_url, true);

    //This function will be called when data returns from the web api
    request.onload = function() {
    //get all the movies records into our movie array
    user_array = JSON.parse(request.responseText);
    //console.log("length of user - " + user_array.length)
    //console.log("username of user = " + user_array[0].user_id);
        

    //Fetch the comments as well
    fetchUser();
    
    //call the function so as to display all movies tiles for "Now Showing"
    //displayAllGames(category);
    };
    //This command starts the calling of the movies web api
    request.send();
}
function editUser(element) {
    var item = element.getAttribute("item");

    currentIndex = item;

    document.getElementById("username").value = user_array.email ;
    document.getElementById("userpassword").value = user_array.password;
    
}
// Submit or send the new comment to the server to be added.
function updateUser() {
    var response = confirm("Are you sure you want to update this user?");
    if (response == true) {
        var urlParams = new URLSearchParams(window.location.search);
        var yourname = urlParams.getAll('yourname');
    
    var edit_user_url = user_url + "/" + yourname;
    var updateuser = new XMLHttpRequest(); // new HttpRequest instance to send request to server
    
    updateuser.open("PUT", edit_user_url, true); //The HTTP method called 'PUT' is used here as we are updating data
    updateuser.setRequestHeader("Content-Type", "application/json");
    user_array[currentIndex].email = document.getElementById("editusername").value; 
    user_array[currentIndex].password = document.getElementById("edituserpassword").value;
    
    updateuser.onload = function() {
        fetchUser();
    };
    updateuser.send(JSON.stringify(user_array[currentIndex]));
    }
}