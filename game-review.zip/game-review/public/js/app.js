var game_url = "/games";
var game_array = []; // This creates an empty movie array
var gameCount = 0;
/*  There are two categories: "Now Showing" and "Coming Soon". This variable states which 
    category of movies should be listed when the home page is first loaded. */
var category = "PS4";
var currentIndex = 0;

var comment_url = "/comments";
var comment_array = []; //This creates an empty array

var user_url = "/user";
var user_array = [];

var fav_url = "/favourites";
var fav_array = [];

var popcornBWImage = 'images/popcorn_bw.png';
var popcornImage = 'images/popcorn.png';
var rating = 0;