//This function is to call the movies api and get all the movies
//that is showing in Shaw Theatres for Showing Now and Coming Soon
function getGameData() {
    var request = new XMLHttpRequest();
    request.open('GET', game_url, true);

    //This function will be called when data returns from the web api
    request.onload = function() {
    //get all the movies records into our movie array
    game_array = JSON.parse(request.responseText);

    //Fetch the comments as well
    fetchComments();
    
    
    //call the function so as to display all movies tiles for "Now Showing"
    Ps4Games(category);
    XboxGames(category);
    PcGames(category);
    ActionGames(category);
    AdventureGames(category);
    BrGames(category);
    };
    //This command starts the calling of the movies web api
    request.send();
}

function Ps4Games(category)                 
{    
    var table = document.getElementById("ps4Table");    
    var gameCount = 0;    
    var message = "";    

    table.innerHTML = "";    
    totalGames = game_array.length;    
    for (var count = 0; count < totalGames; count++) 
    {        
        if (game_array[count].platform == "PS4")
        {            
            var thumbnail = game_array[count].thumbnail;            
            var title = game_array[count].title;            
            var cell = '<div class="card" style="width: 13rem;">\
            <img src="'+thumbnail+'" class="card-img-top" alt="...">\
            <div class="card-body">\
              <h5 class="card-title">'+ title + ' </h5>\
              <button  href="#" data-toggle="modal" data-target="#gameModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameDetails(this)" >More</button>\
              <button  href="#" data-toggle="modal" data-target="#commentModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameComments(this)" >Comments</button>\
            </div>\
          </div>'
             table.insertAdjacentHTML('beforeend', cell);            
             gameCount++;          
        }    
    }    
    message = gameCount + " Games " + category;    
    document.getElementById("summary").textContent = message;    
    document.getElementById("parent").textContent = "";
}

function XboxGames(category) 
{    
    var table = document.getElementById("xboxTable");    
    var gameCount = 0;    
    var message = "";    

    table.innerHTML = "";    
    totalGames = game_array.length;    
    for (var count = 0; count < totalGames; count++) 
    {        
        if (game_array[count].platform == "XBOX")
        {            
            var thumbnail = game_array[count].thumbnail;            
            var title = game_array[count].title;            
            var cell = '<div class="card" style="width: 13rem;">\
            <img src="'+thumbnail+'" class="card-img-top" alt="...">\
            <div class="card-body">\
              <h5 class="card-title">'+ title + ' </h5>\
              <button  href="#" data-toggle="modal" data-target="#gameModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameDetails(this)" >More</button>\
              <button href="#" data-toggle="modal" data-target="#commentModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameComments(this)" >Comments</button>\
            </div>\
          </div>'
             table.insertAdjacentHTML('beforeend', cell);            
             gameCount++;           
        }    
    }    
    message = gameCount + " Games " + category;    
    document.getElementById("summary").textContent = message;    
    document.getElementById("parent").textContent = "";
}

function PcGames(category) 
{    
    var table = document.getElementById("pcTable");    
    var gameCount = 0;    
    var message = "";    
    
    table.innerHTML = "";    
    totalGames = game_array.length;    
    for (var count = 0; count < totalGames; count++) 
    {    console.log("fdhajs");
        if (game_array[count].platform == "PC")
        {            
            var thumbnail = game_array[count].thumbnail;            
            var title = game_array[count].title;            
            var cell = '<div class="card" style="width: 13rem;">\
            <img src="'+thumbnail+'" class="card-img-top" alt="...">\
            <div class="card-body">\
              <h5 class="card-title">'+ title + ' </h5>\
              <button  href="#" data-toggle="modal" data-target="#gameModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameDetails(this)" >More</button>\
              <button href="#" data-toggle="modal" data-target="#commentModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameComments(this)" >Comments</button>\
            </div>\
          </div>'
             table.insertAdjacentHTML('beforeend', cell);            
             gameCount++;            
        }    
    }    
    message = gameCount + " Games " + category;    
    document.getElementById("summary").textContent = message;    
    document.getElementById("parent").textContent = "";
}

function ActionGames(category) 
{    
    var table = document.getElementById("actionTable");    
    var gameCount = 0;    
    var message = "";    
    
    table.innerHTML = "";    
    totalGames = game_array.length;    
    for (var count = 0; count < totalGames; count++) 
    {    console.log("fdhajs");
        if (game_array[count].genre == "Action")
        {            
            var thumbnail = game_array[count].thumbnail;            
            var title = game_array[count].title;            
            var cell = '<div class="card" style="width: 13rem;">\
            <img src="'+thumbnail+'" class="card-img-top" alt="...">\
            <div class="card-body">\
              <h5 class="card-title">'+ title + ' </h5>\
              <button  href="#" data-toggle="modal" data-target="#gameModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameDetails(this)" >More</button>\
              <button href="#" data-toggle="modal" data-target="#commentModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameComments(this)" >Comments</button>\
            </div>\
          </div>'
             table.insertAdjacentHTML('beforeend', cell);            
             gameCount++;        
        }    
    }    
    message = gameCount + " Games " + category;    
    document.getElementById("summary").textContent = message;    
    document.getElementById("parent").textContent = "";
}

function AdventureGames(category) 
{    
    var table = document.getElementById("adventureTable");    
    var gameCount = 0;    
    var message = "";    
    
    table.innerHTML = "";    
    totalGames = game_array.length;    
    for (var count = 0; count < totalGames; count++) 
    {    console.log("fdhajs");
        if (game_array[count].genre == "Adventure")
        {            
            var thumbnail = game_array[count].thumbnail;            
            var title = game_array[count].title;            
            var cell = '<div class="card" style="width: 13rem;">\
            <img src="'+thumbnail+'" class="card-img-top" alt="...">\
            <div class="card-body">\
              <h5 class="card-title">'+ title + ' </h5>\
              <button  href="#" data-toggle="modal" data-target="#gameModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameDetails(this)" >More</button>\
              <button href="#" data-toggle="modal" data-target="#commentModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameComments(this)" >Comments</button>\
            </div>\
          </div>'
             table.insertAdjacentHTML('beforeend', cell);            
             gameCount++;        
        }    
    }    
    message = gameCount + " Games " + category;    
    document.getElementById("summary").textContent = message;    
    document.getElementById("parent").textContent = "";
}

function BrGames(category) 
{    
    var table = document.getElementById("brTable");    
    var gameCount = 0;    
    var message = "";    
    
    table.innerHTML = "";    
    totalGames = game_array.length;    
    for (var count = 0; count < totalGames; count++) 
    {    console.log("fdhajs");
        if (game_array[count].genre == "Battle Royale")
        {            
            var thumbnail = game_array[count].thumbnail;            
            var title = game_array[count].title;            
            var cell = '<div class="card" style="width: 13rem;">\
            <img src="'+thumbnail+'" class="card-img-top" alt="...">\
            <div class="card-body">\
              <h5 class="card-title">'+ title + ' </h5>\
              <button  href="#" data-toggle="modal" data-target="#gameModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameDetails(this)" >More</button>\
              <button href="#" data-toggle="modal" data-target="#commentModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showGameComments(this)" >Comments</button>\
            </div>\
          </div>'
             table.insertAdjacentHTML('beforeend', cell);            
             gameCount++;      
        }    
    }    
    message = gameCount + " Games " + category;    
    document.getElementById("summary").textContent = message;    
    document.getElementById("parent").textContent = "";
}

function listPs4Games() {
    category = "PS4";
    Ps4Games(category);
    document.getElementById("gameTitle").textContent = game_array[item].title;
    document.getElementById("gamePoster").src = game_array[item].thumbnail;
}

function listXboxGames() {
    category = "XBOX";
    XboxGames(category);
    document.getElementById("gameTitle").textContent = game_array[item].title;
    document.getElementById("gamePoster").src = game_array[item].thumbnail;
}

function listPcGames() {
    category = "PC";
    PcGames(category);
    document.getElementById("gameTitle").textContent = game_array[item].title;
    document.getElementById("gamePoster").src = game_array[item].thumbnail;
}

function listActionGames() {
    category = "Action";
    ActionGames(category);
    document.getElementById("gameTitle").textContent = game_array[item].title;
    document.getElementById("gamePoster").src = game_array[item].thumbnail;
}

function listAdventureGames() {
    category = "Adventure";
    AdventureGames(category);
    document.getElementById("gameTitle").textContent = game_array[item].title;
    document.getElementById("gamePoster").src = game_array[item].thumbnail;
}

function listBrGames() {
    category = "Battle Royale";
    BrGames(category);
    document.getElementById("gameTitle").textContent = game_array[item].title;
    document.getElementById("gamePoster").src = game_array[item].thumbnail;
}

function showGameDetails(element) {
    var item = element.getAttribute("item");
    currentIndex = item;
    document.getElementById("gameTitle").textContent = game_array[item].title;
    document.getElementById("gamePoster").src = game_array[item].thumbnail;
    document.getElementById("genre").textContent = game_array[item].genre;
    document.getElementById("platform").textContent = game_array[item].platform;
    document.getElementById("rating").textContent = game_array[item].rating;
    document.getElementById("download").textContent = game_array[item].download;
    document.getElementById("description").textContent = game_array[item].description;
    document.getElementById("trailer1").src = game_array[item].trailer;
}

function addBookmark() {
  var urlParams = new URLSearchParams(window.location.search);
  var username = urlParams.getAll('yourname');
  var favourite = new Object();
  favourite.gameid = game_array[currentIndex].game_id; // Movie ID is required by server to create new comment  // Movie title is required by server to create new comment
  favourite.username = username;
  

  var postfavourite = new XMLHttpRequest(); // new HttpRequest instance to send comment

  postfavourite.open("POST", fav_url, true); //Use the HTTP POST method to send data to server

  postfavourite.setRequestHeader("Content-Type", "application/json");
  postfavourite.onload = function() {
    fetchFavorite(); // fetch all comments again so that the web page can have updated comments.     
  };
// Convert the data in Comment object to JSON format before sending to the server.
  postfavourite.send(JSON.stringify(favourite)); 
}
